GREEN PODS ASSIGNMENT 2 — AVOCADO RIPENING CLASSIFICATION

FILES
- notebooks/01_eda_and_data_cleaning.ipynb
- notebooks/02_classical_ml_svm.ipynb
- notebooks/03_mobilenetv2_transfer_learning.ipynb
- notebooks/04_model_comparison_and_demo.ipynb
- Assignment2_Avocado_Ripening_Report.pdf
- requirements.txt

DATASET
Download the assignment dataset from the supplied Google Drive URL. Extract images into:
data/raw/underripe/
data/raw/breaking/
data/raw/ripe/
data/raw/overripe/

Run notebooks in order. In each notebook, update DATA_DIR if your folder path differs.
Notebook 02 and 03 calculate metrics from the dataset; notebook 04 compares saved metrics.
The report deliberately leaves results as placeholders until you run the experiment. Replace them
with measured values and add confusion matrices before submitting.
